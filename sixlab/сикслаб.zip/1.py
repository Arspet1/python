total = 0
for _ in range(20):
    total += 1
    print(total)    